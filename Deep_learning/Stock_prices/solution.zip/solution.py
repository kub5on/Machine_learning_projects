import keras
import tensorflow as tf
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.layers import LSTM, GRU, Dense, Dropout, BatchNormalization
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import mean_squared_error
import keras_tuner as kt

keras.utils.set_random_seed(43)
tf.config.experimental.enable_op_determinism()

# Wczytanie i przygotowanie danych
df = pd.read_csv("sp500.txt")
df = df.sort_values("Date")
data = df[["Close"]].values

train_data, test_data = train_test_split(data, test_size=0.2, shuffle=False)

scaler = MinMaxScaler()
train_scaled = scaler.fit_transform(train_data)
test_scaled = scaler.transform(test_data)

def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i + seq_length])
        y.append(data[i + seq_length])
    return np.array(X), np.array(y)

seq_length = 60
X_train, y_train = create_sequences(train_scaled, seq_length)
X_test, y_test = create_sequences(test_scaled, seq_length)

# (batch, timesteps, features)
X_train = X_train.reshape((X_train.shape[0], X_train.shape[1], 1))
X_test = X_test.reshape((X_test.shape[0], X_test.shape[1], 1))

# Funkcja budująca model LSTM
def build_lstm_model(hp):
    model = Sequential()
    model.add(LSTM(
        units=hp.Int('lstm_units_1', min_value=32, max_value=128, step=32),
        return_sequences=True,
        input_shape=(seq_length, 1)
    ))
    model.add(BatchNormalization())
    model.add(Dropout(
        rate=hp.Float('dropout_1', min_value=0.1, max_value=0.5, step=0.1)
    ))
    model.add(LSTM(
        units=hp.Int('lstm_units_2', min_value=32, max_value=128, step=32)
    ))
    model.add(Dropout(
        rate=hp.Float('dropout_2', min_value=0.1, max_value=0.5, step=0.1)
    ))
    model.add(Dense(1))
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
    return model

# Funkcja budująca model GRU
def build_gru_model(hp):
    model = Sequential()
    model.add(GRU(
        units=hp.Int('gru_units_1', min_value=32, max_value=128, step=32),
        return_sequences=True,
        input_shape=(seq_length, 1)
    ))
    model.add(BatchNormalization())
    model.add(Dropout(
        rate=hp.Float('dropout_1', min_value=0.1, max_value=0.5, step=0.1)
    ))
    model.add(GRU(
        units=hp.Int('gru_units_2', min_value=32, max_value=128, step=32)
    ))
    model.add(Dropout(
        rate=hp.Float('dropout_2', min_value=0.1, max_value=0.5, step=0.1)
    ))
    model.add(Dense(1))
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
    return model

# Tuning hiperparametrów (ZAKOMENTUJ PRZED WYSYŁKĄ!)
# tuner_lstm = kt.RandomSearch(
#     build_lstm_model,
#     objective='val_loss',
#     max_trials=3,
#     executions_per_trial=1,
#     directory='lstm_dir',
#     project_name='lstm',
#     seed=42
# )
# tuner_lstm.search(X_train, y_train, epochs=10, batch_size=32, validation_split=0.1, shuffle=False)
# best_lstm = tuner_lstm.get_best_models(num_models=1)[0]
# best_lstm.save("best_lstm.h5")

# tuner_gru = kt.RandomSearch(
#     build_gru_model,
#     objective='val_loss',
#     max_trials=3,
#     executions_per_trial=1,
#     directory='gru_dir',
#     project_name='gru',
#     seed=42
# )
# tuner_gru.search(X_train, y_train, epochs=10, batch_size=32, validation_split=0.1, shuffle=False)
# best_gru = tuner_gru.get_best_models(num_models=1)[0]
# best_gru.save("best_gru.h5")

# Wczytanie wytrenowanych modeli
best_lstm = tf.keras.models.load_model("best_lstm.h5")
best_gru = tf.keras.models.load_model("best_gru.h5")

# Predykcje
pred_lstm = scaler.inverse_transform(best_lstm.predict(X_test))
pred_gru = scaler.inverse_transform(best_gru.predict(X_test))
y_test_inv = scaler.inverse_transform(y_test)

rmse_lstm = np.sqrt(mean_squared_error(y_test_inv, pred_lstm))
rmse_gru = np.sqrt(mean_squared_error(y_test_inv, pred_gru))

print("RMSE LSTM: ", rmse_lstm)
print("RMSE GRU: ", rmse_gru)